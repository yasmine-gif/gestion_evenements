

    <div class=container-fluid  >
<style> .copy_text{
    color: wheat;
height: 50px;


}</style>
    <div class="row bg bg-dark copy_text justify-content-center  pt-2" ><img src="img/copyr.png" alt="">Copyright ©EVENEMENTO • Tous droits reservés</div>

    </div>
